package Clases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Personas {
	
	private int id_concursantes;
	private String nombre;
	private String apellido;
	private int dni;
	private String email;
	private String pass;
	private String telefono;
	
		
	public Personas(int id_concursantes, String nombre, String apellido, int dni, String email, String pass,
			String telefono) 
	{
		super();
		this.id_concursantes = id_concursantes;
		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
		this.email = email;
		this.pass = pass;
		this.telefono = telefono;
	}

	public int getId_concursantes() {
		return id_concursantes;
	}
	public void setId_concursantes(int id_concursantes) {
		this.id_concursantes = id_concursantes;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public int getDni() {
		return dni;
	}
	public void setDni(int dni) {
		this.dni = dni;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	
	
}
