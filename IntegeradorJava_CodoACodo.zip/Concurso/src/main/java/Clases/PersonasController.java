package Clases;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/PersonasController")
public class PersonasController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public PersonasController() {
        super();
    }
        
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PersonasDAO personaDAO=null;
		
		try
		{
			personaDAO=new PersonasDAO();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		String accion;
		RequestDispatcher dispatcher=null;
		
		accion=request.getParameter("accion");
		
		if(accion==null||accion.isEmpty())
		{
			dispatcher=request.getRequestDispatcher("index.html");
		}
		else if(accion.equals("registrar"))
		{	
			String nombre=request.getParameter("nameR");
			String apellido=request.getParameter("surenameR");
			int dni=Integer.parseInt(request.getParameter("dniR"));
			String mail=request.getParameter("mailR");
			String pass=request.getParameter("passR");
			String telefono=request.getParameter("phoneR");
			Personas p=new Personas(0,nombre,apellido,dni,mail,pass,telefono);
			personaDAO.insertPersona(p);
			dispatcher=request.getRequestDispatcher("vistas/exitos.html");
		}
		else if(accion.equals("login"))
		{
			String email=request.getParameter("mailL");
			String pass=request.getParameter("passL");
			int i=personaDAO.validarPersona(email, pass);
			if(i==1)
			{	
				dispatcher=request.getRequestDispatcher("vistas/admLog.jsp");
			}
			else if(i==2)
			{
				dispatcher=request.getRequestDispatcher("vistas/bienvenidos.html");
			}
			else
			{
				dispatcher=request.getRequestDispatcher("index.html");
			}
		}
		else if(accion.equals("actualizar"))
		{	
			int id=Integer.parseInt(request.getParameter("idE"));
			String nombre=request.getParameter("nameE");
			String apellido=request.getParameter("surenameE");
			int dni=Integer.parseInt(request.getParameter("dniE"));
			String mail=request.getParameter("mailE");
			String pass=request.getParameter("passE");
			String telefono=request.getParameter("phoneE");
			Personas p=new Personas(id,nombre,apellido,dni,mail,pass,telefono);
			personaDAO.actualizarPersona(p);
			dispatcher=request.getRequestDispatcher("vistas/admLog.jsp");
		}
		else if(accion.equals("insert"))
		{
			String nombre=request.getParameter("nameE");
			String apellido=request.getParameter("surenameE");
			int dni=Integer.parseInt(request.getParameter("dniE"));
			String mail=request.getParameter("mailE");
			String pass=request.getParameter("passE");
			String telefono=request.getParameter("phoneE");
			Personas p=new Personas(0,nombre,apellido,dni,mail,pass,telefono);
			personaDAO.insertPersona(p);
			dispatcher=request.getRequestDispatcher("vistas/admLog.jsp");
		}
		else if(accion.equals("nuevo"))
		{
			dispatcher=request.getRequestDispatcher("vistas/nuevo.jsp");
		}
		else if(accion.equals("editar"))
		{	
			dispatcher=request.getRequestDispatcher("vistas/editar.jsp");
		}
		else if(accion.equals("eliminar"))
		{	
			int id=Integer.parseInt(request.getParameter("id"));
			personaDAO.eliminarPersona(id);
			dispatcher=request.getRequestDispatcher("vistas/admLog.jsp");
		}
		
		dispatcher.forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
				
		
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
