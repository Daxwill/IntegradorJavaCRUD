package Clases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PersonasDAO {
	
	Connection conexion;
	
	public PersonasDAO() throws ClassNotFoundException
	{
		Conexion con=new Conexion();
		conexion=con.getConnection();
	}
	
	public List<Personas> listarPersonas()
	{
		PreparedStatement ps;
		ResultSet rs;
		List<Personas> lista=new ArrayList<>();
		
		try
		{
			ps=conexion.prepareStatement("select * from concursantes");
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				int id=rs.getInt("id_concursantes");
				String nombre=rs.getString("nombre");
				String apellido=rs.getString("apellido");
				int dni=rs.getInt("dni");
				String mail=rs.getString("email");
				String pass=rs.getString("contraseña");
				String telefono=rs.getString("telefono");
				
				Personas p=new Personas(id,nombre,apellido,dni,mail,pass,telefono);
				lista.add(p);
			}
		}
		catch(SQLException e)
		{
			System.out.print("Error de Conexcion 2");
			e.printStackTrace();
			return null;
		}
		return lista;	
	}
	
	public Personas mostrarPersonas(int idd)
	{
		PreparedStatement ps;
		ResultSet rs;
		Personas p=null;
		
		try
		{
			ps=conexion.prepareStatement("select * from concursantes where id_concursantes=?");
			ps.setInt(1, idd);
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				int id=rs.getInt("id_concursantes");
				String nombre=rs.getString("nombre");
				String apellido=rs.getString("apellido");
				int dni=rs.getInt("dni");
				String mail=rs.getString("email");
				String pass=rs.getString("contraseña");
				String telefono=rs.getString("telefono");
				
				p=new Personas(id,nombre,apellido,dni,mail,pass,telefono);
			}
			return p;
		}
		catch(SQLException e)
		{
			System.out.print("Error de Conexcion 3");
			e.printStackTrace();
			return null;
		}	
	}
	
	public boolean insertPersona(Personas p)
	{
		PreparedStatement ps;	
		try
		{
			ps=conexion.prepareStatement("INSERT INTO concursantes (id_concursantes,nombre,apellido,dni,email,contraseña,telefono) VALUES(?,?,?,?,?,?,?)");
			ps.setInt(1, 0);
			ps.setString(2, p.getNombre());
			ps.setString(3, p.getApellido());
			ps.setInt(4, p.getDni());
			ps.setString(5, p.getEmail());
			ps.setString(6, p.getPass());
			ps.setString(7, p.getTelefono()); 
			ps.execute();
				
			return true;
		}
		catch(SQLException e)
		{	
			System.out.print("Error de Conexcion 4");
			e.printStackTrace();
			return false;
		}		
	}
	
	public boolean actualizarPersona(Personas p)
	{
		PreparedStatement ps;
					
		try
		{
			ps=conexion.prepareStatement("UPDATE concursantes SET nombre=?, apellido=?, dni=?, email=?, contraseña=?, telefono=? where id_concursantes=?");
			ps.setString(1, p.getNombre());
			ps.setString(2, p.getApellido());
			ps.setInt(3, p.getDni());
			ps.setString(4, p.getEmail());
			ps.setString(5, p.getPass());
			ps.setString(6, p.getTelefono());
			ps.setInt(7, p.getId_concursantes());
			ps.execute();
				
			return true;
		}
		catch(SQLException e)
		{
			System.out.print("Error de Conexcion 5");
			e.printStackTrace();
			return false;
		}
				
	}
	
	public boolean eliminarPersona(int idd)
	{
		PreparedStatement ps;
					
		try
		{
			ps=conexion.prepareStatement("delete from concursantes where id_concursantes=?");
			ps.setInt(1, idd);
			ps.execute();
				
			return true;
		}
		catch(SQLException e)
		{
			System.out.print("Error de Conexcion 6");
			e.printStackTrace();
			return false;
		}
				
	}
	
	public int validarPersona(String a, String b)
	{
		PreparedStatement ps;
		ResultSet rs;
		int r=0;	
		final String admin="admin";
		
		try
		{
			ps=conexion.prepareStatement("select * from concursantes where email=? and contraseña=?");
			ps.setString(1, a);
			ps.setString(2, b);
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				int id=rs.getInt("id_concursantes");
				String nombre=rs.getString("nombre");
				String apellido=rs.getString("apellido");
				int dni=rs.getInt("dni");
				String mail=rs.getString("email");
				String pass=rs.getString("contraseña");
				String telefono=rs.getString("telefono");
				Personas p=new Personas(id,nombre,apellido,dni,mail,pass,telefono);
				
				if(p.getEmail().equals(admin)&& p.getPass().equals(admin))
				{
					return 1;
				}
				else
				{
					return 2;
				}
			}
		return 0;
		}
		catch(SQLException e)
		{
			System.out.print("Error de Conexcion 7");
			return 0;
		}
				
	}
}
